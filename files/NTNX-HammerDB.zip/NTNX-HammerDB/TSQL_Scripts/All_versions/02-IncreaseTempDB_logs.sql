
/* Each modify statement should be 4 GB or 8 GB larger than the previous one. */

Use master
go
ALTER DATABASE tempdb MODIFY FILE (NAME = templog01, filename = 'T:\TempDB-logs01\templog01.ldf', SIZE
= 8096);
GO
ALTER DATABASE tempdb MODIFY FILE (NAME = templog01, FILENAME = 'T:\TempDB-logs01\templog01.ldf', SIZE
= 12288);
GO