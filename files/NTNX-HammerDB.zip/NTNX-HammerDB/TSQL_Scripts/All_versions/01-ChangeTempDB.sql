use master
go
Alter database tempdb modify file (name = tempdev, filename = 'H:\TEMPDB01\tempdb01.mdf', SIZE = 4096, FILEGROWTH=0)
go
Alter database tempdb modify file (name = templog, filename = 'T:\TempDB-logs01\templog01.ldf', SIZE = 4096, FILEGROWTH=0)
go
Alter database tempdb ADD file (name = tempdev02, filename = 'H:\TEMPDB01\tempdb02.ndf', SIZE = 4096, FILEGROWTH=0)
go
Alter database tempdb ADD file (name = tempdev03, filename = 'I:\TEMPDB02\tempdb03.ndf', SIZE = 4096, FILEGROWTH=0)
go
Alter database tempdb ADD file (name = tempdev04, filename = 'I:\TEMPDB02\tempdb04.ndf', SIZE = 4096, FILEGROWTH=0)
go

ALTER DATABASE [tempdb] MODIFY FILE (NAME=N'tempdev', NEWNAME=N'tempdev01')
GO
ALTER DATABASE [tempdb] MODIFY FILE (NAME=N'templog', NEWNAME=N'templog01')
GO
