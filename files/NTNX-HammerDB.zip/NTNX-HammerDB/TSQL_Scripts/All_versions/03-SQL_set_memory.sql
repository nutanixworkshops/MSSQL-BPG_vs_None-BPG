/* 
Bruno Sousa | bruno.sousa@nutanix.com

Sets SQL memory based on the following metrics :
  80% of the OS memory as SQL minimum memory 
  80% of the OS memory as SQL maximum memory  
*/


USE master;
exec sp_configure 'show advanced options', 1;
RECONFIGURE;
GO
DECLARE 
        @total_mem decimal (10,0),
		@min int,
		@max int
SELECT 
   --SELECT (physical_memory_kb/1024) AS Server_Physical_Memory_MB
  @total_mem = (physical_memory_kb/1024)
FROM sys.dm_os_sys_info

set @min = @total_mem * 0.8
set @max = @total_mem * 0.8
print @min
print @max
--print @total_mem


EXEC sp_configure 'min server memory (MB)',@min
EXEC sp_configure 'max server memory (MB)',@max
RECONFIGURE
