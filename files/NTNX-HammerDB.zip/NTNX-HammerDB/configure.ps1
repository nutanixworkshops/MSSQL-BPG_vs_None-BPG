  # Script to configure the SQL Server for BPG and NONE BPG
# -------------------------------------------------------

# Get the number of drives
$num_drives=(get-disk).Number.Count

if ($num_drives -gt 2){
    # we have detected more than 2 drives! Initailizing, formating and assigning drive letters to the new drives
    ## set script execution policy 
    Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy unrestricted -force

    # Initialize all disks
    Initialize-Disk -Number 2,3,4,5,6,7,8 -Confirm:$false

    # Format SQL backup/restore disk
    New-Partition -DiskNumber 7 -DriveLetter R -UseMaximumSize

    # Format DB DATA drives
    New-Partition -DiskNumber 2 -DriveLetter F -UseMaximumSize
    New-Partition -DiskNumber 3 -DriveLetter G -UseMaximumSize

    # Format DB TEMP drives
    New-Partition -DiskNumber 4 -DriveLetter H -UseMaximumSize
    New-Partition -DiskNumber 5 -DriveLetter I -UseMaximumSize

    # Format DB LOGS drives
    New-Partition -DiskNumber 8 -DriveLetter T -UseMaximumSize
    New-Partition -DiskNumber 6 -DriveLetter L -UseMaximumSize

    Format-Volume -DriveLetter R -AllocationUnitSize 65536 -FileSystem NTFS -NewFileSystemLabel "SQLBCK" -Confirm:$false -AsJob

    Start-Sleep -s 5

    Format-Volume -DriveLetter F -AllocationUnitSize 65536 -FileSystem NTFS -NewFileSystemLabel "DATA01" -Confirm:$false -AsJob
    Format-Volume -DriveLetter G -AllocationUnitSize 65536 -FileSystem NTFS -NewFileSystemLabel "DATA02" -Confirm:$false -AsJob

    Start-Sleep -s 5

    Format-Volume -DriveLetter H -AllocationUnitSize 65536 -FileSystem NTFS -NewFileSystemLabel "TEMPDB01" -Confirm:$false -AsJob
    Format-Volume -DriveLetter I -AllocationUnitSize 65536 -FileSystem NTFS -NewFileSystemLabel "TEMPDB02" -Confirm:$false -AsJob

    Start-Sleep -s 5

    Format-Volume -DriveLetter T -AllocationUnitSize 65536 -FileSystem NTFS -NewFileSystemLabel "TEMPDBLOG01" -Confirm:$false -AsJob
    Format-Volume -DriveLetter L -AllocationUnitSize 65536 -FileSystem NTFS -NewFileSystemLabel "ULOG01" -Confirm:$false -AsJob
}

# Enable Remote Desktop
# 1) Enable Remote Desktop
set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server'-name "fDenyTSConnections" -Value 0
# 2) Allow incoming RDP on firewall
Enable-NetFirewallRule -DisplayGroup "Remote Desktop"
# 3) Enable secure RDP authentication
set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -name "UserAuthentication" -Value 1


# Disable the firewall
netsh advfirewall set allprofiles state off

# Disable Windows Updates
$AUSettings = (New-Object -com "Microsoft.Update.AutoUpdate").Settings
$AUSettings.NotificationLevel="1"
$AUSettings.Save()

# Disable IE security
$AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
$UserKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value 0
Set-ItemProperty -Path $UserKey -Name "IsInstalled" -Value 0
Stop-Process -Name Explorer

# Set Windows Power Options to High Performance
powercfg -s 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c

Install-WindowsFeature -Name Net-Framework-Core

# Automatically log Administrator in at boot
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v AutoAdminLogon /t REG_DWORD /d 00000001 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultUserName /t REG_SZ /d Administrator /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultPassword /t REG_SZ /d "nutanix/4u" /f


# Disable servermamnager on startup
New-ItemProperty -Path HKCU:\Software\Microsoft\ServerManager -Name DoNotOpenServerManagerAtLogon -PropertyType DWORD -Value "0x1" -Force 

# Wait a minute to have the drives formated before we are ready to proceed
Sleep -s 60

# Create the needed directories and change sql files based on BPG or none BPG
if ($num_drives -lt 3){
    # Creating the Directories
    mkdir C:\SQLDATA01\
    mkdir C:\SQLDATA02\
    mkdir C:\TEMPDB01\
    mkdir C:\TEMPDB02\
    mkdir C:\UserDB-logs01\
    mkdir C:\TempDB-logs01\
    mkdir C:\SQLBACK
    # Changing the files
    ((Get-Content -path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\01-ChangeTempDB.sql -Raw) -replace 'H:','C:') | Set-Content -Path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\01-ChangeTempDB.sql
    ((Get-Content -path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\01-ChangeTempDB.sql -Raw) -replace 'T:','C:') | Set-Content -Path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\01-ChangeTempDB.sql
    ((Get-Content -path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\01-ChangeTempDB.sql -Raw) -replace 'I:','C:') | Set-Content -Path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\01-ChangeTempDB.sql
    ((Get-Content -path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\02-IncreaseTempDB_logs.sql -Raw) -replace 'T:','C:') | Set-Content -Path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\02-IncreaseTempDB_logs.sql
    ((Get-Content -path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\04-SQL-ChangeDefaultPaths.sql -Raw) -replace 'F:','C:') | Set-Content -Path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\04-SQL-ChangeDefaultPaths.sql
    ((Get-Content -path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\04-SQL-ChangeDefaultPaths.sql -Raw) -replace 'L:','C:') | Set-Content -Path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\04-SQL-ChangeDefaultPaths.sql
    ((Get-Content -path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\04-SQL-ChangeDefaultPaths.sql -Raw) -replace 'R:','C:') | Set-Content -Path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\04-SQL-ChangeDefaultPaths.sql
    ((Get-Content -path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\create-ntnxdb\Create-SQL2014-ntnxdb.sql -Raw) -replace 'F:','C:') | Set-Content -Path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\create-ntnxdb\Create-SQL2014-ntnxdb.sql
    ((Get-Content -path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\create-ntnxdb\Create-SQL2014-ntnxdb.sql -Raw) -replace 'G:','C:') | Set-Content -Path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\create-ntnxdb\Create-SQL2014-ntnxdb.sql
    ((Get-Content -path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\create-ntnxdb\Create-SQL2014-ntnxdb.sql -Raw) -replace 'L:','C:') | Set-Content -Path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\create-ntnxdb\Create-SQL2014-ntnxdb.sql
    ((Get-Content -path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\create-ntnxdb\Create-SQL2014-ntnxdb.sql -Raw) -replace '40','10') | Set-Content -Path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\create-ntnxdb\Create-SQL2014-ntnxdb.sql
    ((Get-Content -path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\create-ntnxdb\Create-SQL2014-ntnxdb.sql -Raw) -replace '80','10') | Set-Content -Path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\create-ntnxdb\Create-SQL2014-ntnxdb.sql
    
}else{
    mkdir F:\SQLDATA01\
    mkdir G:\SQLDATA02\
    mkdir H:\TEMPDB01\
    mkdir I:\TEMPDB02\
    mkdir L:\UserDB-logs01\
    mkdir T:\TempDB-logs01\
    mkdir R:\SQLBACK
    ((Get-Content -path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\create-ntnxdb\Create-SQL2014-ntnxdb.sql -Raw) -replace '40','10') | Set-Content -Path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\create-ntnxdb\Create-SQL2014-ntnxdb.sql
    ((Get-Content -path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\create-ntnxdb\Create-SQL2014-ntnxdb.sql -Raw) -replace '80','10') | Set-Content -Path C:\ntnx-hammerdb\TSQL_Scripts\All_versions\create-ntnxdb\Create-SQL2014-ntnxdb.sql
}

# Installing the needed MSSQL Parameters
echo "Adding  T1117 parameter . This parameter forces MS SQL Server to grow all database files uniformly" 
.\SQL_Configuration\Add-SqlServerStartupParameter.ps1 '-T1117'
echo "Adding  T1118 parameter . This parameter forces MS SQL Server to use full extents only" 
.\SQL_Configuration\Add-SqlServerStartupParameter.ps1 '-T1118'
echo " Restarting SQL Server services "
restart-service MSSQL* -force
echo "done"

# Reboot
shutdown /r /t 0
 
